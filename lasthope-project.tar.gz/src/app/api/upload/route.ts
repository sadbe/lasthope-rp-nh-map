import { NextRequest, NextResponse } from 'next/server';
import { writeFile, mkdir } from 'fs/promises';
import path from 'path';
import crypto from 'crypto';
import { requireAdmin } from '@/lib/auth';

// POST /api/upload — accepts a file (FormData), saves it to /public/uploads/markers/
// and returns the relative URL path. Used for marker screenshot/image uploads.
//
// Admin-only, same defense-in-depth pattern as the other mutating routes:
// middleware.ts blocks unauthenticated requests at the edge, requireAdmin()
// here is the source of truth if middleware is ever misconfigured.
//
// SECURITY NOTE: the extension is derived from the (server-verified) MIME
// type via ALLOWED_TYPES, never from the client-supplied `file.name`. A
// previous version took `file.name.split('.').pop()` directly — since
// file.name is fully attacker-controlled on a raw API call (not just
// through the UI), a crafted name like "a.png/../../../../tmp/x" would
// carry the "/../.." straight into the extension and therefore into the
// path.join() below, escaping the uploads directory. MIME-derived
// extensions can't contain path separators, which closes that off.
const ALLOWED_TYPES: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/gif': 'gif',
};
const MAX_SIZE = 5 * 1024 * 1024; // 5MB

// Magic-byte signatures — the declared Content-Type on a FormData file is
// just a client-supplied string, trivially spoofed by anyone hitting this
// endpoint directly (not through the browser file picker). Checking the
// actual leading bytes defends against e.g. an .html/.js payload uploaded
// with a forged "image/png" MIME type.
function hasValidMagicBytes(buffer: Buffer, mime: string): boolean {
  const b = buffer;
  switch (mime) {
    case 'image/jpeg':
      return b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff;
    case 'image/png':
      return b.length >= 8 && b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
    case 'image/gif':
      return b.length >= 4 && b.subarray(0, 4).toString('ascii') === 'GIF8';
    case 'image/webp':
      return b.length >= 12 && b.subarray(0, 4).toString('ascii') === 'RIFF' && b.subarray(8, 12).toString('ascii') === 'WEBP';
    default:
      return false;
  }
}

export async function POST(req: NextRequest) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const formData = await req.formData();
    const file = formData.get('file') as File | null;
    if (!file) {
      return NextResponse.json({ error: 'no file provided' }, { status: 400 });
    }

    const ext = ALLOWED_TYPES[file.type];
    if (!ext) {
      return NextResponse.json({ error: 'only image files are allowed (jpeg/png/webp/gif)' }, { status: 400 });
    }

    if (file.size > MAX_SIZE) {
      return NextResponse.json({ error: 'max file size is 5MB' }, { status: 400 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    if (!hasValidMagicBytes(buffer, file.type)) {
      return NextResponse.json({ error: 'file content does not match declared image type' }, { status: 400 });
    }

    // Filename is fully server-generated — hex hash + a whitelisted
    // extension only, nothing derived from client input goes into it.
    const hash = crypto.randomBytes(16).toString('hex');
    const filename = `marker_${hash}.${ext}`;

    const uploadDir = path.join(process.cwd(), 'public', 'uploads', 'markers');
    await mkdir(uploadDir, { recursive: true });

    const filePath = path.join(uploadDir, filename);
    await writeFile(filePath, buffer);

    // Served back via /api/uploads/markers/[filename] (Next.js doesn't serve
    // files added to /public at runtime, only at build time).
    const imageUrl = `/api/uploads/markers/${filename}`;
    return NextResponse.json({ imageUrl }, { status: 201 });
  } catch (err) {
    console.error('Upload error:', err);
    return NextResponse.json({ error: 'upload failed' }, { status: 500 });
  }
}

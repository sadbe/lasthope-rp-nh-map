---
Task ID: 1
Agent: main
Task: Fix UI bugs — Unicode squares, dark theme too dark, title invisible

Work Log:
- Analyzed user screenshot with VLM — confirmed icons showing as squares (rare Unicode chars ⭳⭱ not rendering), title barely visible, everything too dark
- Replaced all rare/risky Unicode characters in ZoneMapApp.tsx:
  - ⭳ → ⬇ (export), ⭱ → ⬆ (import)
  - ∆ → ▲ (measure), ▦ → ⊞ (grid), ◈ → ◆ (layers)
  - ☾ → ◑ (moon/dark mode toggle), □ → ⛶ (fullscreen)
- Lightened dark theme CSS variables in globals.css:
  - --void: #111 → #1a1a1a, --panel: #181818 → #202020
  - --text-dim: #666 → #888 (much more readable)
  - --text: #b8 → #ccc, --text-bright: #e8 → #f2
  - Reduced vignette and grain opacity (0.55 → 0.4, 0.5 → 0.35)
- Reduced title dissolve animation opacity dips (0.35 → 0.7, 0.6 → 0.85)
- Reduced chromatic aberration layer opacity (::before 0.65→0.5, ::after 0.45→0.35)
- Fixed subtitle: color from var(--text-dim) → var(--text), font-size 8→9
- Fixed MobileSearchBar: removed inline `display: 'none'` style, CSS now controls visibility
- Fixed search-compact CSS: default `display: none`, mobile override `display: block !important`
- Increased mobile title size from 12px → 14px, subtitle 7px → 8px
- Reduced mobile grain overlay opacity 0.25 → 0.15

Stage Summary:
- All rare Unicode chars replaced with universally supported alternatives
- Dark theme significantly lightened for better contrast
- Title and subtitle much more visible
- Build succeeds, app ready for testing
